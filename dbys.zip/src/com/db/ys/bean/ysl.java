package com.db.ys.bean;

public class ysl {
    private int id;
    private float pf;
    private String pm;
    private String tp;
    private String zt;
    private String bm;
    private String dy;
    private String zy;
    private String lx;
    private String dq;
    private String yy;
    private String sytime;
    private String pctime;
    private String gxtime;
    private String js;
    private String gkdz;
    private String xzdz;
    public  ysl(){}
    public ysl(int id, float pf, String pm, String tp, String zt, String bm, String dy, String zy, String lx, String dq, String yy, String sytime, String pctime, String gxtime, String js, String gkdz, String xzdz) {
        this.id = id;
        this.pf = pf;
        this.pm = pm;
        this.tp = tp;
        this.zt = zt;
        this.bm = bm;
        this.dy = dy;
        this.zy = zy;
        this.lx = lx;
        this.dq = dq;
        this.yy = yy;
        this.sytime = sytime;
        this.pctime = pctime;
        this.gxtime = gxtime;
        this.js = js;
        this.gkdz = gkdz;
        this.xzdz = xzdz;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getPf() {
        return pf;
    }

    public void setPf(float pf) {
        this.pf = pf;
    }

    public String getPm() {
        return pm;
    }

    public void setPm(String pm) {
        this.pm = pm;
    }

    public String getTp() {
        return tp;
    }

    public void setTp(String tp) {
        this.tp = tp;
    }

    public String getZt() {
        return zt;
    }

    public void setZt(String zt) {
        this.zt = zt;
    }

    public String getBm() {
        return bm;
    }

    public void setBm(String bm) {
        this.bm = bm;
    }

    public String getDy() {
        return dy;
    }

    public void setDy(String dy) {
        this.dy = dy;
    }

    public String getZy() {
        return zy;
    }

    public void setZy(String zy) {
        this.zy = zy;
    }

    public String getLx() {
        return lx;
    }

    public void setLx(String lx) {
        this.lx = lx;
    }

    public String getDq() {
        return dq;
    }

    public void setDq(String dq) {
        this.dq = dq;
    }

    public String getYy() {
        return yy;
    }

    public void setYy(String yy) {
        this.yy = yy;
    }

    public String getSytime() {
        return sytime;
    }

    public void setSytime(String sytime) {
        this.sytime = sytime;
    }

    public String getPctime() {
        return pctime;
    }

    public void setPctime(String pctime) {
        this.pctime = pctime;
    }

    public String getGxtime() {
        return gxtime;
    }

    public void setGxtime(String gxtime) {
        this.gxtime = gxtime;
    }

    public String getJs() {
        return js;
    }

    public void setJs(String js) {
        this.js = js;
    }

    public String getGkdz() {
        return gkdz;
    }

    public void setGkdz(String gkdz) {
        this.gkdz = gkdz;
    }

    public String getXzdz() {
        return xzdz;
    }

    public void setXzdz(String xzdz) {
        this.xzdz = xzdz;
    }
}
