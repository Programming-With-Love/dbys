package com.db.ys.service;

import com.db.ys.dao.yscz;

public class yssj {
    public yssj(){}
    public void getsysj(){
       yscz cz= new yscz();
      // cz.sysj();
    }
}
